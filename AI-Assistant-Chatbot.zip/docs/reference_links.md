### Reference Links

##### [Documentation FastAPI](https://fastapi.tiangolo.com/tutorial/)

##### [YTB: Course from freeCodeCamp](https://www.youtube.com/watch?v=0sOvCWFmrtA)

##### [Repo: Course from freeCodeCamp](https://github.com/Sanjeev-Thiyagarajan/fastapi-course/tree/main)

##### [YTB: Course from JVP Design](https://www.youtube.com/playlist?list=PLqAmigZvYxIL9dnYeZEhMoHcoP4zop8-p)

##### [Repo: Implement Google Sign-In](https://github.com/amoprocedures/fastapi-with-google-oauth/tree/master)
